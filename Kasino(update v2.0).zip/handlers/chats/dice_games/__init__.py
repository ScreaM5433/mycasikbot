from .cube_game_handler  import dp
from .darts_game_handler import dp
from .basket_game_handler import dp
from .football_game_handler import dp
from .boul_game_handler import dp
from .slots_game_handler import dp
from .dice_games_handler  import dp



__all__ = ["dp"]
