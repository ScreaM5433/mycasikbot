from .commands import dp
from .check_sub import dp
from .mines_callback_handler import dp
from .mines_handler import dp
from .main_menu import dp
from .games_menu import dp
from .admin_menu import dp
from .cabinet_menu import dp
from .add_bal_qiwi import dp

__all__ = ["dp"]